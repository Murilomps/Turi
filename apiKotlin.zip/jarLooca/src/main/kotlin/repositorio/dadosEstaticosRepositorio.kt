package repositorio

import com.github.britooo.looca.api.core.Looca
import dominio.dadosEstaticos
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate

class dadosEstaticosRepositorio (val jdbcTemplate: JdbcTemplate) {
val repositorio = Looca()
    fun inserir(est:dadosEstaticos) {
        jdbcTemplate.update("""
            insert into computador (fk_empresa, sistema_operacional , memoria_total ,
            disco_total, cpu_nucleos_fisicos, cpu_nucleos_logicos, endereco_mac) values (?,?,?,?,?,?,?)
        """, 1, est.sistema_operacional, est.memoria_total, est.disco_total,
            repositorio.processador.numeroCpusFisicas, repositorio.processador.numeroCpusLogicas,est.mac)
    }

    fun visualizarEst():List<dadosEstaticos> {
        return jdbcTemplate.query("select * from computador"
            , BeanPropertyRowMapper(dadosEstaticos::class.java))
    }

    fun visualizarMac(mac:String):List<dadosEstaticos> {
        return jdbcTemplate.query("SELECT id FROM computador WHERE endereco_mac = '$mac'"
            , BeanPropertyRowMapper(dadosEstaticos::class.java))
    }
}