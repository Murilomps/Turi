package configuracao

fun main() {
    val jdbcTemplate = Conexao().getJdbcTemplate()

    jdbcTemplate.execute("""
        create table IF NOT EXISTS dadosEstaticos (
        id int primary key auto_increment,
        fabricante varchar(45),
        arquitetura int,
        so varchar(45),
        modeloDisco varchar(45),
        tamanhoDiscoGB double,
        totalMemoriaGB double,
        fabricanteCPU varchar(45),
        modeloCPU varchar(45)
        );
        
        create table IF NOT EXISTS dadosDinamicos (
        id int primary key auto_increment,
        data_hora TIMESTAMP,
        cpu_porcentagem double,
        disco_usado double,
        memoria_usada double,
        memoria_disponivel double,
        temperatura double
        );
        
    """.trimIndent())
}