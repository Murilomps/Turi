package dominio

import java.time.LocalDateTime

data class dadosDinamicos(
    var id:Int,
    var data_hora:LocalDateTime,
    var cpu_porcentagem:Double,
    var disco_usado:Double,
    var memoria_usada:Double,
    var memoria_disponivel:Double,
)
{
    constructor():this(0, LocalDateTime.now(),0.0,0.0,0.0,0.0)
}
