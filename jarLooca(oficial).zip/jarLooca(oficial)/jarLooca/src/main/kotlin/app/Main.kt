package app

import com.github.britooo.looca.api.core.Looca
import configuracao.Conexao
import dominio.dadosDinamicos
import dominio.dadosEstaticos
import repositorio.dadosDinamicosRepositorio
import repositorio.dadosEstaticosRepositorio
import java.time.LocalDateTime
import java.util.*
// import javax.swing.JOptionPane.showInputDialog
import javax.swing.JOptionPane.showMessageDialog
import kotlin.concurrent.schedule
import oshi.SystemInfo
import java.text.DecimalFormat

open class Main {
    companion object {
        @JvmStatic fun main(args: Array<String>) {
            val jdbcTemplate = Conexao().getJdbcTemplate()
            val repositorioEst = dadosEstaticosRepositorio(jdbcTemplate)
            val repositorioDin = dadosDinamicosRepositorio(jdbcTemplate)


            // chamando biblioteca Looca e variáveis dele

            val looca = Looca()
            val sistema = looca.sistema
            val memoria = looca.memoria
            val processador = looca.processador
            //  val grupoProcessos = looca.grupoDeProcessos
            val grupoDiscos = looca.grupoDeDiscos
            val disco = grupoDiscos.discos[0]

            println("Chegando nos dados estáticos.")

            val df = DecimalFormat("###.##")

            // dados estáticos
            val SO = sistema.sistemaOperacional
            var totalMem = df.format(memoria.total.toDouble() / 1024 / 1024 / 1024)
            totalMem = "${totalMem.substring(0,totalMem.indexOf(","))}.${totalMem.substring(totalMem.indexOf(",")+1,totalMem.length)}"
            val totalMemoriaGB = totalMem.toDouble()

            var totalDisco = df.format(disco.tamanho.toDouble() / 1024 / 1024 / 1024)
            totalDisco = "${totalDisco.substring(0,totalDisco.indexOf(","))}.${totalDisco.substring(totalDisco.indexOf(",")+1,totalDisco.length)}"
            val tamanhoDiscoGB = totalDisco.toDouble()

            val numeroCpusFisicas = processador.numeroCpusFisicas
            val numeroCpusLogicas = processador.numeroCpusLogicas

            var mac = ""
            val networks = SystemInfo().hardware.networkIFs
            for (network in networks) {
                if(network.ifAlias == "Ethernet") {
                    mac = network.macaddr
                    break
                }
            }
            if (mac == "") {
                mac = networks[0].macaddr
            }
            mac = mac.replace(":", "")

            val novodadosEstaticos =
                dadosEstaticos(0, SO, totalMemoriaGB, tamanhoDiscoGB, numeroCpusFisicas, numeroCpusLogicas, mac)
            if (repositorioEst.visualizarMac(mac).isEmpty()) {
                repositorioEst.inserir(novodadosEstaticos)
                println("Inserindo...")
                println("Dados estáticos inseridos.")
                repositorioDin.lerDinamicos()
            } else {
                println("Máquina já existente")
                repositorioDin.lerDinamicos()
            }

        }
    }
}

//fun Perguntar(repositorioEst:dadosEstaticosRepositorio, repositorioDin:dadosDinamicosRepositorio) {
//    val visualizarDados =
//        showInputDialog("Visualizar: \r\n - Para dados estáticos, digite 1 \r\n - Para dados dinâmicos, digite 2 \r\n Para nenhum, digite qualquer coisa")
//    when (visualizarDados){
//        "1" -> DadosEstaticos(repositorioEst)
//        "2" -> DadosDin(repositorioDin)
//        else -> {
//            print("Fim")
//            return
//        }
//    }
//    Perguntar(repositorioEst, repositorioDin)
//}

//fun DadosEstaticos(repositorioEst: dadosEstaticosRepositorio){
//    val consultaEst = repositorioEst.visualizarEst()
//    var mensagem = "Dados estáticos: \r\n"
//    consultaEst.forEach {
//        mensagem += """
//            - id:${it.id}
//            - sistema operacional: ${it.sistema_operacional}
//            - total da memória (GB): ${it.memoria_total}
//            - tamanho do disco (GB): ${it.disco_total}
//            - CPU's físicas: ${it.cpu_nucleos_fisicos}
//            - CPU's lógicas: ${it.cpu_nucleos_logicos}
//        """.trimIndent()
//    }
//    println(mensagem)
//}

//fun DadosDin(repositorioDin: dadosDinamicosRepositorio){
//    val consultaDim = repositorioDin.visualizarDin()
//    var mensagem = "Dados dinâmicos: \r\n"
//        consultaDim.forEach {
//            mensagem += """
//            - id:${it.id}
//            - Porcentagem CPU (%): ${"%.2f".format(it.cpu_porcentagem)}
//            - Disco Usado (GB): ${"%.2f".format(it.disco_usado)}
//            - Memória Usada (GB): ${"%.2f".format(it.memoria_usada)}
//            - Memória Disponível (GB): ${"%.2f".format(it.memoria_disponivel)}
//        """.trimIndent()
//        }
//        DadosDin(repositorioDin)
//    print(mensagem)
//}