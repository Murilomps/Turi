package dominio

data class dadosEstaticos(
    var id:Int,
    var sistema_operacional:String,
    var memoria_total:Double,
    var disco_total:Double,
    var cpu_nucleos_fisicos:Int,
    var cpu_nucleos_logicos:Int,
    var mac:String
    )
    {
        constructor():this(0,"",0.0,0.0,0,0, "")
    }

