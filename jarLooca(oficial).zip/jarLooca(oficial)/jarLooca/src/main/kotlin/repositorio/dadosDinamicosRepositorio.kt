package repositorio

import com.github.britooo.looca.api.core.Looca
import dominio.dadosDinamicos
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate
import oshi.SystemInfo
import java.text.DecimalFormat
import java.time.LocalDateTime
import javax.swing.JOptionPane

class dadosDinamicosRepositorio (val jdbcTemplate: JdbcTemplate) {
    val repositorio = Looca()
    fun inserirDin(dim: dadosDinamicos) {
        jdbcTemplate.update("""
            insert into leitura (fk_computador, data_hora, cpu_porcentagem,
            disco_usado,memoria_usada,memoria_disponivel) values (?,?,?,?,?,?)
        """, dim.id, dim.data_hora, dim.cpu_porcentagem,dim.disco_usado,dim.memoria_usada,dim.memoria_disponivel)
    }

    fun visualizarDin():List<dadosDinamicos> {
        return jdbcTemplate.query("select * from leitura"
            , BeanPropertyRowMapper(dadosDinamicos::class.java)
        )
    }

    fun lerDinamicos() {
        val repositorioEst = dadosEstaticosRepositorio(jdbcTemplate)
        var mac = ""
        val networks = SystemInfo().hardware.networkIFs
        for (network in networks) {
            if(network.ifAlias == "Ethernet") {
                mac = network.macaddr
                break
            }
        }
        if (mac == "") {
            mac = networks[0].macaddr
        }
        mac = mac.replace(":", "")

        // dinâmicos
        val idComputador = repositorioEst.visualizarMac(mac)[0].id

        val repositorioDin = dadosDinamicosRepositorio(jdbcTemplate)
        println("Chegando nos dados dinâmicos.")

        val looca = Looca()
        val memoria = looca.memoria
        val grupoProcesso = looca.grupoDeProcessos
        val processador = looca.processador

        val df = DecimalFormat("###.##")

        var usoCpu = df.format(processador.uso)
        usoCpu = usoCpu.replace(",",".")
        val porcentagemCpu = usoCpu.toDouble()

        var conversaoDisco = looca.grupoDeDiscos.volumes[0].total - looca.grupoDeDiscos.volumes[0].disponivel
        var usoDisco = df.format(conversaoDisco.toDouble() / 1024 / 1024 / 1024)
        usoDisco = usoDisco.replace(",",".")
        val discoUsado = usoDisco.toDouble()

        var usoMemoria = df.format(memoria.emUso.toDouble() / 1024 / 1024 / 1024)
        usoMemoria = usoMemoria.replace(",",".")
        val memoriaUsada = usoMemoria.toDouble()

        var dispMemoria = df.format(memoria.disponivel.toDouble() / 1024 / 1024 / 1024)
        dispMemoria = dispMemoria.replace(",",".")
        val memoriaDisponivel = dispMemoria.toDouble()

        println(porcentagemCpu)
        println(discoUsado)
        println(memoriaUsada)
        println(memoriaDisponivel)

       val novoDadosDinamicos = dadosDinamicos(
           idComputador,
            LocalDateTime.now(),
            porcentagemCpu,
            discoUsado,
            memoriaUsada,
            memoriaDisponivel
        )
        repositorioDin.inserirDin(novoDadosDinamicos)
        println("Inserindo...")
        println("Dados dinâmicos inseridos.")
        lerDinamicos()
    }
}